function f1() {
			let im=document.getElementById("im")
			let som=navigator.userAgent;
			if (som.indexOf("OPR") != -1)
			{
				im.onmouseover = function () {im.style.width="36%";}
				im.onmouseout = function () {im.style.width="30%";}

			}
			else if (som.indexOf("Firefox") != -1)
			{
				im.onmouseover = function () {im.style.width="24%";}
				im.onmouseout = function () {im.style.width="30%";}
			}
			else
			{
				im.onmouseover = function () {im.setAttribute('src',"img/101.png")}
				im.onmouseout = function () {im.setAttribute('src',"img/10.png")}
			}
		}